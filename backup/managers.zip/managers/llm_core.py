import os
import gc
import logging
from typing import List, Dict, Generator, Optional, Any, Tuple
from llama_cpp import Llama

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


class LLMEngine:
    """
    Production-Ready Llama Engine
    - Full Sampling Stack
    - Context Sliding Window
    - Deterministic Mode
    - Hardware Tuning
    """

    def __init__(self):
        self.llm: Optional[Llama] = None
        self.model_name: str = ""
        self.model_path: str = ""
        self.n_ctx: int = 4096
        self.safety_margin: int = 256

    # ==========================================================
    # Utility
    # ==========================================================

    def _clamp(self, val, min_v, max_v):
        return max(min_v, min(val, max_v))


    # ==========================================================
    # Model Management
    # ==========================================================

    def load_model(self, model_path: str, **params) -> Tuple[bool, str]:
        try:
            self.unload_model()

            if not os.path.exists(model_path):
                return False, f"❌ File not found: {model_path}"

            logger.info(f"Loading model: {model_path}")
            
            # 🟢 1. จัดการ Default Parameters (ป้องกัน UI ส่งค่ามาไม่ครบ)
            self.n_ctx = int(params.get("n_ctx", 4096))
            
            llm_kwargs = {
                "model_path": model_path,
                "n_ctx": self.n_ctx,
                # ตั้งค่า Default เป็น -1 เพื่อบังคับโยนทุก Layer ลง GPU เสมอ
                "n_gpu_layers": int(params.get("n_gpu_layers", -1)), 
                "n_threads": int(params.get("n_threads", 4)),
                "n_batch": int(params.get("n_batch", 512)),
                "seed": int(params.get("seed", -1)),
                "logits_all": True,
                "verbose": False
            }

            # 🟢 2. จัดการ Boolean flags แบบรวบรัด
            for bool_key, default in [("f16_kv", True), ("use_mmap", True), ("use_mlock", False), ("flash_attn", True)]:
                llm_kwargs[bool_key] = bool(params.get(bool_key, default))

            # 🟢 3. จัดการ Rope scaling (ถ้าไม่มีก็ปล่อยผ่าน ไม่ต้องใส่ใน kwargs)
            if "rope_scaling_type" in params:
                llm_kwargs["rope_scaling_type"] = params["rope_scaling_type"]
            if "rope_freq_base" in params:
                llm_kwargs["rope_freq_base"] = float(params["rope_freq_base"])
            if "rope_freq_scale" in params:
                llm_kwargs["rope_freq_scale"] = float(params["rope_freq_scale"])

            logger.info(f"LLM params: {llm_kwargs}")

            self.llm = Llama(**llm_kwargs)

            # Deterministic seed
            if params.get("seed") is not None:
                try:
                    llm_kwargs["seed"] = int(params.get("seed"))
                except Exception:
                    llm_kwargs["seed"] = -1
            else:
                llm_kwargs["seed"] = -1

            # Always include these safety flags
            llm_kwargs["logits_all"] = True
            llm_kwargs["verbose"] = False

            logger.info(f"LLM params: {llm_kwargs}")

            self.llm = Llama(**llm_kwargs)

            self.model_path = model_path
            self.model_name = os.path.basename(model_path)

            return True, f"✅ Loaded: {self.model_name}"

        except Exception as e:
            logger.error(f"Load Error: {e}")
            return False, str(e)

    def unload_model(self):
        if self.llm:
            del self.llm
            self.llm = None
            gc.collect()
            logger.info("Model unloaded.")
        self.model_name = ""

    # ==========================================================
    # Token Counting
    # ==========================================================

    def count_tokens(self, text: str) -> int:
        if not self.llm:
            return 0
        try:
            return len(self.llm.tokenize(text.encode("utf-8")))
        except Exception as e:
            logger.warning(f"Tokenize failed, using estimation. Error: {e}")
            return len(text) // 3

    # ==========================================================
    #  Generation Json 
    # ==========================================================
    
    def generate_json(self, messages: List[Dict[str, str]], params: Dict[str, Any]) -> str:
        if not self.llm:
            return "{}"

        call_kwargs = {
            "messages": messages,
            # 🟢 1. เพิ่ม max_tokens ให้เยอะขึ้นเพื่อให้เขียน JSON จบประโยค
            "max_tokens": int(params.get("max_tokens", 1024)), 
            "temperature": 0.0, 
            "stream": False,
            # 🟢 2. บังคับให้ Llama ตอบกลับมาเป็นโครงสร้าง JSON เท่านั้น
            "response_format": {"type": "json_object"} 
        }

        try:
            self.llm.reset() 
            response = self.llm.create_chat_completion(**call_kwargs)
            content = response["choices"][0]["message"]["content"]
            
            # 🟢 3. ปริ้นท์ดูว่า mem0 สกัดความจำอะไรออกมาได้บ้าง
            logger.info(f"\n[mem0 Extraction]: {content}\n")
            
            return content
        except Exception as e:
            logger.error(f"JSON Generation Error: {e}")
            return "{}"
            
    # ==========================================================
    #  Generation 
    # ==========================================================

    def completion_stream(
        self,
        messages: List[Dict[str, str]],
        params: Dict[str, Any]
    ) -> Generator[str, None, None]:

        if not self.llm:
            yield "⚠️ No model loaded."
            return
        #use params  UI 
        #params = self._apply_profile(params)

        max_tokens = int(params.get("max_tokens", 512))

        temperature = self._clamp(float(params.get("temperature", 0.7)), 0.0, 2.0)
        top_k = int(params.get("top_k", 40))
        top_p = self._clamp(float(params.get("top_p", 0.95)), 0.0, 1.0)
        min_p = self._clamp(float(params.get("min_p", 0.0)), 0.0, 1.0)
        typical_p = self._clamp(float(params.get("typical_p", 1.0)), 0.0, 1.0)
        tfs_z = float(params.get("tfs_z", 1.0))

        repeat_penalty = float(params.get("repeat_penalty", 1.1))
        frequency_penalty = float(params.get("frequency_penalty", 0.0))
        presence_penalty = float(params.get("presence_penalty", 0.0))
        penalty_last_n = int(params.get("penalty_last_n", 64))

        mirostat_mode = int(params.get("mirostat_mode", 0))
        mirostat_tau = float(params.get("mirostat_tau", 5.0))
        mirostat_eta = float(params.get("mirostat_eta", 0.1))

        try:
            # Build a safe kwargs dict for the Llama create_chat_completion call.
            # Some versions of llama_cpp do not accept all sampling kwargs
            # (e.g. `penalty_last_n`). Filter to only include supported keys
            # and avoid passing None values which can cause native errors.
            call_kwargs: Dict[str, Any] = {
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "top_k": top_k,
                "top_p": top_p,
                "min_p": min_p,
                "typical_p": typical_p,
                "tfs_z": tfs_z,
                "repeat_penalty": repeat_penalty,
                "frequency_penalty": frequency_penalty,
                "presence_penalty": presence_penalty,
                # mirostat params may be unsupported depending on build
                "mirostat_mode": mirostat_mode,
                "mirostat_tau": mirostat_tau,
                "mirostat_eta": mirostat_eta,
                "logit_bias": params.get("logit_bias"),
                "grammar": params.get("grammar"),
                "stop": params.get("stop"),
                "stream": True,
            }

            # Seed should be an int or omitted
            if params.get("seed") is not None:
                try:
                    call_kwargs["seed"] = int(params.get("seed"))
                except Exception:
                    pass

            # Remove any keys with value None
            call_kwargs = {k: v for k, v in call_kwargs.items() if v is not None}

            # Some llama_cpp builds do not accept certain kwargs (e.g. penalty_last_n).
            # Explicitly drop known-unsupported keys if present in params.
            unsupported = ["penalty_last_n"]
            for k in unsupported:
                if k in call_kwargs:
                    del call_kwargs[k]

            logger.info(f"Calling create_chat_completion with: {call_kwargs}")

            stream = self.llm.create_chat_completion(**call_kwargs)

            for chunk in stream:
                delta = chunk.get("choices", [])[0].get("delta", {})
                content = delta.get("content")
                if content:
                    yield content

        except Exception as e:
            logger.error(f"Generation Error: {e}")
            yield f"\n[Backend Error: {str(e)}]"