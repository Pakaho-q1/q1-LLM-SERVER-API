import json
import logging
import asyncio
import re
import datetime
from typing import Dict, Any, Callable, List
from pathlib import Path

logger = logging.getLogger(__name__)

class ChatOrchestrator:
    def __init__(self, engine, history, executor):
        self.engine = engine
        self.history = history
        self.executor = executor
        self.log_file = Path("memory_log.txt")
               
    def _write_debug_log(self, phase: str, content: Any):
        """บันทึกความเคลื่อนไหวของ Logic ลงไฟล์เพื่อการตรวจสอบ"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"\n[{timestamp}] === {phase} ===\n")
            if isinstance(content, list):
                for msg in content:
                    f.write(f"  {msg['role'].upper()}: {msg['content'][:200]}...\n")
            else:
                f.write(f"  {str(content)}\n")

    def _stabilize_input(self, user_input: str):
        if not user_input or not user_input.strip():
            raise ValueError("Input content cannot be empty")
        
        # 🟢 เพิ่มความยืดหยุ่น: ตรวจสอบและนับ Token อย่างปลอดภัย
        token_count = 0
        
        if hasattr(self.engine, 'count_tokens'):
            # ถ้ามีฟังก์ชัน count_tokens ให้เรียกใช้ปกติ
            token_count = self.engine.count_tokens(user_input)
            
        elif hasattr(self.engine, 'llm') and hasattr(self.engine.llm, 'tokenize'):
            # ถ้าใช้ llama-cpp-python จะมีคำสั่ง tokenize ติดมากับตัวโมเดล
            token_count = len(self.engine.llm.tokenize(user_input.encode("utf-8")))
            
        else:
            # ถ้าไม่มีอะไรเลย ให้ประมาณค่าคร่าวๆ (1 คำแยกด้วยช่องว่าง ≈ 1.5 Token)
            token_count = len(user_input.split()) * 1.5

        # ดึงค่า Context limit อย่างปลอดภัย (ตั้งค่าพื้นฐานไว้ที่ 4096)
        n_ctx = getattr(self.engine, 'n_ctx', 4096)
        
        if token_count > (n_ctx * 0.5):
            raise ValueError(f"Input too large (estimated {int(token_count)} tokens)")

    async def process_chat(
        self,
        conv_id: str,
        user_input: str,
        params: Dict[str, Any],
        status_cb: Callable,
        chunk_cb: Callable,
        messages: List[Dict[str, Any]] = None,
    ):
        try:
            self._stabilize_input(user_input)
            self._write_debug_log("INPUT RECEIVED", user_input)

            if messages is None:
                messages = []

                system_prompt = params.get(
                    "system_prompt",
                    "You are a precise AI assistant."
                )

                # ========================
                # 1) Long-term Memory (LIMITED)
                # ========================
                await status_cb("Searching long-term memory...")
                memories = self.history.search_memories(
                    user_input,
                    conv_id,
                    limit=3,              # 🔥 limit
                    score_threshold=0.25  # 🔥 relevance control
                )

                messages.append({
                    "role": "system",
                    "content": system_prompt
                })

                if memories:
                    mem_texts = []
                    for m in memories:
                        content = m.get("memory", m.get("text", str(m)))
                        mem_texts.append(f"- {content}")

                    messages.append({
                        "role": "system",
                        "content": "[Relevant long-term memory]\n" + "\n".join(mem_texts)
                    })

                # ========================
                # 2) Token-aware working memory
                # ========================
                token_aware_history = self.history.finalize_context(
                    conv_id,
                    params,
                    user_input,
                    system_tokens_estimate=500,
                    memory_tokens_estimate=300,
                    response_tokens_estimate=params.get("max_tokens", 512)
                )

                messages.extend(token_aware_history)

            self._write_debug_log("FINAL PROMPT CONTEXT", messages)

            await status_cb("Generating response...")
            full_text = ""

            core_engine = None
            if hasattr(self.engine, "completion_stream"):
                core_engine = self.engine
            else:
                for attr_name in dir(self.engine):
                    try:
                        attr = getattr(self.engine, attr_name)
                        if hasattr(attr, "completion_stream"):
                            core_engine = attr
                            break
                    except Exception:
                        pass

            if not core_engine:
                raise AttributeError("completion_stream not found")

            parameters = params.get("parameters", params)

            for chunk in core_engine.completion_stream(messages, parameters):
                if chunk:
                    full_text += chunk
                    await chunk_cb(chunk)

            clean_text = re.sub(
                r'<think>.*?</think>',
                '',
                full_text,
                flags=re.DOTALL
            ).strip()

            await status_cb("Saving interaction to memory...")

            self.history.add_message(conv_id, "user", user_input)
            self.history.add_message(conv_id, "assistant", clean_text)

            interaction = [
                {"role": "user", "content": user_input},
                {"role": "assistant", "content": clean_text}
            ]

            # 🔥 selective memory save
            if self.history.should_store_long_term(interaction):
                future = self.executor.submit(
                    self.history.save_to_memory,
                    interaction,
                    conv_id
                )

            self._write_debug_log("RESPONSE SAVED", clean_text)

        except Exception as e:
            logger.exception("Orchestrator Error")
            self._write_debug_log("ERROR", str(e))
            raise e