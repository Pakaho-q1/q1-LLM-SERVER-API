import sqlite3
import json
import uuid
import time
from datetime import datetime
from typing import List, Dict, Any, Callable, Set
from mem0 import Memory
from mem0.llms.base import LLMBase

class MyLocalLLM(LLMBase):
    def __init__(self, engine):
        self.engine = engine
        
    def _get_core_engine(self):
        """ฟังก์ชันควานหา LLMEngine ที่ซ่อนอยู่ใน ModelManager"""
        if hasattr(self.engine, 'generate_json'):
            return self.engine
        # สมมติว่าใน ModelManager คุณเก็บ LLMEngine ไว้ในตัวแปรชื่อ engine หรือ llm_engine
        if hasattr(self.engine, 'engine') and hasattr(self.engine.engine, 'generate_json'):
            return self.engine.engine
        if hasattr(self.engine, 'llm_engine'):
            return self.engine.llm_engine
        return self.engine # Fallback

    def generate_response(self, messages: list, **kwargs) -> str:
        core = self._get_core_engine()
        
        # เช็คอย่างปลอดภัยว่าคลาส Core มี .llm และโหลดไว้แล้วหรือยัง
        if not hasattr(core, 'llm') or core.llm is None:
            return ""
            
        params = {
            "max_tokens": kwargs.get("max_tokens", 512),
            "temperature": 0.0 
        }
        # เรียก generate_json จาก llm_core.py
        response = core.generate_json(messages, params)
        return response

class HistoryManager:
    def __init__(self, engine, db_path: str = "data/chat.db", n_ctx: int = 4096, tokenizer_fn: Callable = None):
        self.engine = engine 
        self.db_path = db_path
        self.n_ctx = n_ctx
        self.tokenizer = tokenizer_fn 
        self.safety_margin = 350
        
        self._init_db()
        config = {
            "vector_store": {
                "provider": "qdrant",
                "config": {
                    "collection_name": "chat_memory", 
                    "path": "data/mem0_qdrant",
                    "embedding_model_dims": 384  # 🟢 เพิ่มบรรทัดนี้ลงไปครับ! นี่คือกุญแจสำคัญ
                }
            },
            "embedder": {
                "provider": "huggingface",
                "config": {"model": "sentence-transformers/all-MiniLM-L6-v2"}
            },
            "llm": {
                "provider": "openai",
                "config": {
                    "api_key": "dummy_key", 
                    "model": "gpt-3.5-turbo"
                }
            }
        }
        
        self.memory = Memory.from_config(config)
        self.memory.llm = MyLocalLLM(self.engine)

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:           
            
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS sessions 
                (id TEXT PRIMARY KEY, title TEXT, created_at REAL, updated_at REAL)''')           
            cursor.execute('''CREATE TABLE IF NOT EXISTS messages 
                (id TEXT PRIMARY KEY, conv_id TEXT, role TEXT, content TEXT, 
                 tokens INTEGER, request_id TEXT UNIQUE, message_id TEXT, metadata TEXT DEFAULT '{}', is_archived INTEGER DEFAULT 0, created_at REAL)''')
            conn.commit()
        
    # ======================== Session Management ========================
    def create_session(self, title: str = "New Chat") -> Dict[str, Any]:
        """Create a new conversation session"""
        session_id = str(uuid.uuid4())
        now = time.time()
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('INSERT INTO sessions (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)',
                         (session_id, title, now, now))
            conn.commit()
        
        return {"id": session_id, "title": title, "created_at": now, "updated_at": now}

    def get_all_sessions(self) -> List[Dict[str, Any]]:
        """Get all conversation sessions"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT id, title, created_at, updated_at FROM sessions ORDER BY updated_at DESC')
            rows = cursor.fetchall()
        
        return [{"id": r[0], "title": r[1], "created_at": r[2], "updated_at": r[3]} for r in rows]

    def rename_session(self, conv_id: str, title: str) -> None:
        """Rename a conversation session"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE sessions SET title = ?, updated_at = ? WHERE id = ?',
                         (title, time.time(), conv_id))
            conn.commit()

    def delete_session(self, conv_id: str) -> None:
        """Delete a conversation session and all its messages"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM messages WHERE conv_id = ?', (conv_id,))
            cursor.execute('DELETE FROM sessions WHERE id = ?', (conv_id,))
            conn.commit()

    # ======================== Message Management ========================
    def add_message(self, conv_id: str, role: str, content: str, 
                   request_id: str = None, message_id: str = None, metadata: Dict = None) -> Dict[str, Any]:
        """Add a message to conversation history"""
        msg_id = message_id or str(uuid.uuid4())
        now = time.time()
        tokens = self.tokenizer(content) if self.tokenizer else len(content.split())
        metadata_json = json.dumps(metadata or {})
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute('''INSERT INTO messages 
                    (id, conv_id, role, content, tokens, request_id, message_id, metadata, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                    (str(uuid.uuid4()), conv_id, role, content, tokens, request_id, msg_id, metadata_json, now))
                conn.commit()
            except sqlite3.IntegrityError:
                # request_id already exists (duplicate) - ignore
                pass
        
        # Update session's updated_at timestamp
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('UPDATE sessions SET updated_at = ? WHERE id = ?', (time.time(), conv_id))
            conn.commit()
        
        return {"id": msg_id, "role": role, "content": content, "tokens": tokens, "created_at": now}

    def get_chat_history(self, conv_id: str) -> List[Dict[str, Any]]:
        """Get all messages for a conversation"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''SELECT id, role, content, tokens, created_at FROM messages 
                            WHERE conv_id = ? AND is_archived = 0 
                            ORDER BY created_at ASC''', (conv_id,))
            rows = cursor.fetchall()
        
        return [{"id": r[0], "role": r[1], "content": r[2], "tokens": r[3], "created_at": r[4]} for r in rows]

    def get_working_memory(self, conv_id: str, max_tokens: int) -> List[Dict[str, Any]]:
        """Get recent messages within token budget (for context window)"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''SELECT role, content, tokens FROM messages 
                            WHERE conv_id = ? AND is_archived = 0 
                            ORDER BY created_at DESC''', (conv_id,))
            rows = cursor.fetchall()
        
        # Build context from newest to oldest, up to max_tokens
        context = []
        token_count = 0
        
        for role, content, tokens in reversed(rows):  # Reverse to get chronological order
            if token_count + tokens <= max_tokens:
                context.append({"role": role, "content": content})
                token_count += tokens
            else:
                break
        
        return context

    # ======================== Context Finalization ========================
    def finalize_context(
        self,
        conv_id: str,
        options: Dict[str, Any],
        user_input: str,
        system_tokens_estimate: int = 400,
        memory_tokens_estimate: int = 300,
        response_tokens_estimate: int = 512,
    ) -> List[Dict[str, Any]]:

        # 🔥 dynamic budgeting
        available_budget = (
            self.n_ctx
            - system_tokens_estimate
            - memory_tokens_estimate
            - response_tokens_estimate
            - self.safety_margin
        )

        if available_budget < 200:
            available_budget = 200

        context = self.get_working_memory(conv_id, available_budget)

        context.append({
            "role": "user",
            "content": user_input
        })

        return context

    # ======================== Memory Management (mem0) ========================
    def search_memories(
        self,
        query: str,
        conv_id: str,
        limit: int = 3,
        score_threshold: float = 0.2
    ) -> List[Dict]:

        if self.engine is None:
            return []

        try:
            res = self.memory.search(
                query,
                run_id=conv_id,
                limit=limit
            )
        except TypeError:
            res = self.memory.search(query, conv_id)

        if isinstance(res, dict):
            results = res.get("results", [])
        else:
            results = res

        # 🔥 relevance filtering + dedupe
        filtered = []
        seen = set()

        for r in results:
            score = r.get("score", 1.0)
            text = r.get("memory", r.get("text", str(r)))

            if score >= score_threshold and text not in seen:
                filtered.append(r)
                seen.add(text)

        return filtered[:limit]
        
    def should_store_long_term(self, interaction: List[Dict]) -> bool:
        """
        Store only meaningful interactions
        """

        user_text = interaction[0]["content"]
        assistant_text = interaction[1]["content"]

        # 🔥 skip short chatter
        if len(user_text) < 25:
            return False

        keywords = [
            "prefer",
            "use",
            "work on",
            "my project",
            "I always",
            "I don't like",
            "ตั้งค่า",
            "โปรเจก",
            "ชอบ",
            "ไม่ชอบ"
        ]

        combined = (user_text + assistant_text).lower()

        if any(k.lower() in combined for k in keywords):
            return True

        return False

    def save_to_memory(self, messages: List[Dict], conv_id: str) -> None:
        """Save interaction to mem0 for semantic memory"""
        # 🟢 แก้ไข: เหมือนด้านบน
        if self.engine is None: 
            return
            
        try:
            self.memory.add(messages, run_id=conv_id)
        except TypeError:
            try:
                self.memory.add(messages, user_id=conv_id)
            except TypeError:
                self.memory.add(messages)
